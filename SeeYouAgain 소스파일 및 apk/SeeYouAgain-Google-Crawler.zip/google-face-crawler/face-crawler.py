# -*-coding:utf-8
from selenium import webdriver
from time import *
import time
import urllib

import dlib
from PIL import Image
from skimage import io
import matplotlib.pyplot as plt
from pyvirtualdisplay import Display
from slacker import Slacker


def send_noti(str):
    token = 'xoxp-225148617605-225148617717-225089222420-4c7b808e733997e38be2c12e0f38aa0c'
    slack = Slacker(token)
    slack.chat.post_message('#crawler', str)


def detect_faces(image):
    # Create a face detector
    face_detector = dlib.get_frontal_face_detector()

    # Run detector and get bounding boxes of the faces on image.
    detected_faces = face_detector(image, 1)
    face_frames = [(x.left(), x.top(),
                    x.right(), x.bottom()) for x in detected_faces]

    return face_frames


startTime = time.time()

display = Display(visible=0, size=(800, 800))
display.start()
driver = webdriver.Chrome()
queryList = [
    u'남자+어린이', u'여자+어린이',
    u'여자아이', u'남자아이',
    u'여자애', u'남자애',
    u'어린소녀', u'어린소년',
    u'꼬마여자', u'꼬마남자',
    u'10대+여자', u'10대+남자',
    u'20대+여자', u'20대+남자',
    u'30대+여자', u'30대+남자',
    u'40대+여자', u'40대+남자',
    u'50대+여자', u'50대+남자',
    u'아줌마', u'아저씨', u'인물사진', u'정면사진',
    u'할머니', u'할아버지']

for i in range(1, 50):
    queryList.append(str(i) + u'살+남자')
    queryList.append(str(i) + u'살+여자')

for i in range(1, 50):
    queryList.append(str(i) + u'세+남자')
    queryList.append(str(i) + u'세+여자')

namingList = [
    u'teenager_boy', u'teenager_girl',
    u'girl_young', u'boy_young',
    u'girl_young_1', u'boy_young_1',
    u'girl_young_2', u'boy_young_2',
    u'girl_young_3', u'boy_young_3',
    u'10_girl', u'10_boy',
    u'20_girl', u'20_boy',
    u'30_girl', u'30_boy',
    u'40_girl', u'40_boy',
    u'50_girl', u'50_boy',
    u'madame', u'mister', u'portraits', u'front_picture',
    u'grandmother', u'grandfather']

for i in range(1, 50):
    namingList.append(str(i) + u'_age_man')
    namingList.append(str(i) + u'_age_woman')

for i in range(1, 50):
    namingList.append(str(i) + u'_age_man_1')
    namingList.append(str(i) + u'_age_woman_1')

namingIndex = 0
for query in queryList:
    send_noti("[" + namingList[namingIndex] + "](" + str(namingIndex + 1) + "/126) 작업 시작 / 런타임 : " + str(
        time.time() - startTime) + " / 전송시각 : " + strftime("%Y-%m-%d %H:%M:%S"))
    driver.get(
        'https://www.google.co.kr/search?q=' + query +
        '&source=lnms&tbm=isch&sa=X&ved=0ahUKEwiVotba3MvVAhXKbbwKHeg3ARYQ_AUICigB&biw=960&bih=1100')

    i = 0

    # max 500 times scroll
    currentImageCounter = 0
    preImageCounter = 0
    flag = False
    for a in range(500):
        if flag:
            break

        try:
            element = driver.find_element_by_css_selector('.ksb._kvc').click()
            driver.execute_script("arguments[0].click();", element)
            time.sleep(1)
        except:
            driver.execute_script('window.scrollBy(0,1000000)')
            time.sleep(1)

        driver.execute_script('window.scrollBy(0,1000000)')
        time.sleep(1)

        # current scroll images
        preImageCounter = currentImageCounter
        images = driver.find_elements_by_css_selector('.rg_ic.rg_i')
        currentImageCounter = len(images)

        print(len(images))

        # work start when scroll finished
        workLog = ''
        if preImageCounter == currentImageCounter:
            flag = True
            for img in images:
                print(workLog)
                if i % 30 == 0:
                    send_noti("[" + namingList[namingIndex] + "](" + str(namingIndex + 1) + "/126) 중간작업보고 / 이미지 "
                              + str(len(images)) + " 개 중 " + str(i) + " 개 완료 / 런타임 : " + str(
                        time.time() - startTime) + " / 전송시각 : " + strftime(
                        "%Y-%m-%d %H:%M:%S") + "\n 작업로그 : \n" + workLog + "-----------------------------------\n\n")
                    workLog = ''
                src = img.get_attribute('src')
                if src == None:
                    continue

                saveOrigPathWithoutExt = 'origImages/' + namingList[namingIndex] + '_' + str(i)
                saveCropPathWithoutExt = 'cropImages/' + namingList[namingIndex] + '_' + str(i)

                urllib.request.urlretrieve(src, saveOrigPathWithoutExt + '.jpg')

                workLog += 'SAVE ORIGINAL :: ' + saveOrigPathWithoutExt + '.jpg\n'

                # Load image
                img_path = saveOrigPathWithoutExt + '.jpg'
                image = io.imread(img_path)

                # Detect faces
                detected_faces = detect_faces(image)

                j = 0
                # Crop faces and plot
                for n, face_rect in enumerate(detected_faces):
                    face = Image.fromarray(image).crop(face_rect)
                    plt.subplot(1, len(detected_faces), n + 1)
                    plt.axis('off')
                    plt.imshow(face)
                    plt.savefig(saveCropPathWithoutExt + '_crop_' + str(j) + '.jpg', bbox_inches='tight')
                    workLog += 'SAVE CROPED :: ' + saveCropPathWithoutExt + '_crop_' + str(j) + '.png\n'
                    j += 1

                i += 1

    namingIndex += 1

    send_noti("[" + namingList[namingIndex] + "](" + str(namingIndex + 1) + "/126) 작업 완료!! / 런타임 : " + str(
        time.time() - startTime) + " / 전송시각 : " + strftime("%Y-%m-%d %H:%M:%S"))
