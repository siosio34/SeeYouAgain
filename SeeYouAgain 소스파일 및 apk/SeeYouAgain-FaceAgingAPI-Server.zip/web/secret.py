
FIREBASE_BUCKET = 'seeyouagain-f0804.appspot.com'
