<?php
	error_reporting(E_ALL);
        ini_set("display_errors", 1);
	$json = file_get_contents('php://input');
	$jsonArray = json_decode($json, true);
	print_r($jsonArray);
	$jsonArray = $jsonArray["nameValuePairs"];
	$registrationIds = array($jsonArray["token"]);	
	unset($jsonArray["token"]);
	//$jsonArray = array("token"=>"dgJMuRKCaxg:APA91bEA-VnS6-Jruev0bSM3y3xnzthb8raXG2HM1L8xlTgBckdVfh3qREd5OAwh6GVpT9qUN9TNaMQ7bnzVwB3H20yRdaZqDsSUG4SN03ROouq33xg3S3dMmf6Cls-ZuszbH8RDewPU", "name"=>"김만수", "content"=>"알람입니다."); 
	$bodyJson = json_encode($jsonArray);
	$fields = array(
		'registration_ids'  => $registrationIds,
		//'notification'      => $msg,
		'data' => array(
			'message'=>$bodyJson,
		),
    	);
	$headers = array(
		'Authorization: key=AAAA6ObKG-0:APA91bEp-ENbxGG5mVaJ9rMcQC8mvOv3DvVAU5xri9bCNVW1JxGfSA-h_2IrPL1SYr1ZcT38hrWPUt2acJuc2eUb1_4J4j_TF8XQmANblspNXqFgSPFR1mDqV7lmt7B7P6ymRqWwffmz',
		'Content-Type: application/json'
    	);
	$ch = curl_init();
	curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
	curl_setopt( $ch,CURLOPT_POST, true );
	curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
	curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
	$result = curl_exec($ch );
	curl_close( $ch );
	echo $result;
?>
