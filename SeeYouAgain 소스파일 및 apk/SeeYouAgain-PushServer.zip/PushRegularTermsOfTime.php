<?php
	error_reporting(E_ALL);
	ini_set("display_errors", 1);
        require_once('./firebase-php-client/vendor/autoload.php');
	const DEFAULT_URL = 'https://seeyouagain-f0804.firebaseio.com/';	
	const DEFAULT_TOKEN = 'u3TVcVeYFtKpuIAbCkmqvO2TRECJRx21TOzLaKAy';

	$firebase = new \Firebase\FirebaseLib(DEFAULT_URL, DEFAULT_TOKEN);
	$users = $firebase->get("/user");
	$mpis = $firebase->get("/missingChilds");
	$usersArray = json_decode($users, true);
	$mpisArray = json_decode($mpis, true);
	$mpisValues = array_values($mpisArray);
	foreach($usersArray as $user) {
		$registrationIds = array($user["token"]);
		$mpi = $mpisValues[rand(0, count($mpisValues)-1)];
		$mpi["key"] = array_search($mpi, $mpisArray);
		$bodyJson = json_encode($mpi);
		
		$msg = array(
			'body'  => $bodyJson,
			'title'     => "AR-Trace",
			'vibrate'   => 1,
			'sound'     => 1,
		);
		$fields = array(
			'registration_ids'  => $registrationIds,
			//'notification'      => $msg,
			'data' => array(
				'message'=>$bodyJson,
			),
    		);

		$headers = array(
			'Authorization: key=AAAA6ObKG-0:APA91bEp-ENbxGG5mVaJ9rMcQC8mvOv3DvVAU5xri9bCNVW1JxGfSA-h_2IrPL1SYr1ZcT38hrWPUt2acJuc2eUb1_4J4j_TF8XQmANblspNXqFgSPFR1mDqV7lmt7B7P6ymRqWwffmz',
			'Content-Type: application/json'
    		);

		$ch = curl_init();
		curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
		curl_setopt( $ch,CURLOPT_POST, true );
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
		$result = curl_exec($ch );
		curl_close( $ch );
		echo $result;
	}
	
?>
