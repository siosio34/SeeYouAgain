import React from 'react';
import {Header} from '../components/index.js'

class App extends React.Component {
    render() {
        return (
            <div>
                <Header/>
                <h1>This is HOT</h1>
            </div>
        )
    }
}

export default App